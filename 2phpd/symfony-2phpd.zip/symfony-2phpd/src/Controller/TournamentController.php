<?php

namespace App\Controller;

use App\Entity\Tournament;
use App\Entity\User;
use App\Form\TournamentCreateFormType;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Attribute\Route;

class TournamentController extends AbstractController
{
    #[Route('/tournament', name: 'app_tournament')]
    public function index(): Response
    {
        return $this->render('tournament/index.html.twig', [
            'controller_name' => 'TournamentController',
        ]);
    }
    #[Route('/tournament/create', name: 'app_tournament_create')]
    public function createTournament(Request $request, ManagerRegistry $doctrine, SessionInterface $session): Response
    {
        $tournament = new Tournament();
        $form = $this->createForm(TournamentCreateFormType::class,$tournament);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $userRepository = $doctrine->getManager()->getRepository(User::class);
            $user = $userRepository->findOneBy(['id' => $session->get('id')]);

            $entityManager = $doctrine->getManager();
            $tournament->setStatus("en attente");
            $tournament->setOrganizer($user);
            $tournament->setWinner(null);
            $entityManager->persist($tournament);
            $entityManager->flush();
            return $this->redirectToRoute('app_tournament');
        }
        return $this->render('tournament/createTournament.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
